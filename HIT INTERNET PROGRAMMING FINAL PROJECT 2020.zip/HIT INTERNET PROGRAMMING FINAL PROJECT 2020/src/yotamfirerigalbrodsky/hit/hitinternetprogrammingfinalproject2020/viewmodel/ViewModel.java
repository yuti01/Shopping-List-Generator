package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.exceptions.HITFinalProjectException;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.IModel;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view.IView;

import javax.swing.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents a ViewModel for this final project
 */
public class ViewModel implements IViewModel {

    /**
     * view is the IView object to be the view of this instance
     * model is the IModel object to be the model of this instance
     * logger is the logger of this class
     */
    private IView view; // the view object
    private IModel model; // the model object
    private Logger logger = LogManager.getLogger(ViewModel.class); // init the logger

    private ShoppingList shoppingList;

    /**
     * Default constructor
     */
    public ViewModel() {
        logger.info("Creating a ViewModel object (Default Constructor)"); // log info
    }

    /**
     * The constructor of the ViewModel class
     */
    public ViewModel(IView view, IModel model) {
        logger.info("Creating a ViewModel object - setting View and Model objects"); // log info

        this.view = view; // set the view
        this.model = model; // set the model
    }

    public ShoppingList getShoppingList() {
        return shoppingList;
    }

    public void setShoppingList(ShoppingList shoppingList) {
        this.shoppingList = shoppingList;
    }

    /**
     * This method starts this ViewModel object
     */
    @Override
    public void start() {
        logger.info("starting the ViewModel object"); // log info

        Thread thread = new Thread(new Runnable() { // accessing the database through a new thread
            @Override
            public void run() {
                try {
                    logger.info("initializing the Model object"); // log info
                    model.initialize(); // initialize the model
                } catch (HITFinalProjectException e){
                    logger.error(e.getMessage()); // log the error
                }
            }
        });

        thread.start(); // start the thread created above

        logger.info("Model started"); // log info

        logger.info("starting the View"); // log info

        SwingUtilities.invokeLater(new Runnable() { // start the view in the awt thread
            @Override
            public void run() {
                view.start(); // start the view
                logger.info("View started"); // log info
            }
        });

    }

    /**
     * This method gets a ShoppingList object and then keeps it in the data base
     * @param shoppingList the ShoppingList object to be kept in the data base
     */
    @Override
    public void keepDataInDB(ShoppingList shoppingList) {

        new Thread(new Runnable() { // accessing the database through a new thread
            @Override
            public void run() {
                try {
                    logger.info("setting the shopping list in the data base"); // log info
                    model.setShoppingList(shoppingList); // set the shopping list in the data base
                    logger.info("setting completed"); // log info

                    SwingUtilities.invokeLater(new Runnable() { // show message to the user in the UI thread
                        @Override
                        public void run() {
                            JOptionPane.showMessageDialog(null, "Saved successfully",
                                    "Successful Operation", JOptionPane.INFORMATION_MESSAGE); // show message to the user
                        }
                    });
                } catch (HITFinalProjectException e){
                    e.printStackTrace(); // log error
                }
            }
        }).start(); // starting the thread

    }

    /**
     * sets the View object inside the ViewModel
     *
     * @param v the IView object to be set
     */
    @Override
    public void setView(IView v) {
        logger.info("setting the view"); // log info
        this.view = v; // set the View
    }

    /**
     * sets the Model object inside the ViewModel
     *
     * @param m the IModel object to be set
     */
    @Override
    public void setModel(IModel m) {
        logger.info("setting the model"); // log info
        this.model = m; // set the model
    }

    /**
     * checks if the data base is empty
     *
     * @return true if the data base is empty or not initialized
     * false if the data base has some data
     */
    @Override
    public boolean isDataBaseEmpty() {
        try {
            return this.model.isEmpty(); // check if the data base is empty
        } catch (HITFinalProjectException e) {
            e.printStackTrace(); // log error
        }
        return false;
    }

    /**
     * shows the items the costumer should buy in the result screen
     */
    @Override
    public void showTheShouldBuyList(ShoppingList inStock){
        new Thread(new Runnable() { // create a new thread and start it
            @Override
            public void run() {
                try {
                    logger.info("showing the 'Should Buy' shopping list (from another thread)"); // log info
                    ShoppingList shouldHave = model.getShoppingList(); // get the ShoppingList from

                    SwingUtilities.invokeLater(new Runnable() { // in the UI thread
                        @Override
                        public void run() {
                            // calculate the result ShoppingList and set it
                            view.setResultScreenTable(ShoppingList.remainsToBuy(shouldHave, inStock));
                        }
                    });
                } catch (HITFinalProjectException e){
                    e.printStackTrace(); // print the error
                }
            }
        }).start();

    }

    /**
     * This method manages the transition between the "hello"
     * to the screens coming after in the GUI flow
     */
    @Override
    public void manageHelloScreenTransition(){
        new Thread(new Runnable() { // check if the data base is empty in a new thread
            @Override
            public void run() {
                try {
                    if (model.isEmpty()) { // empty data base
                        logger.warn("shopping list is not defined"); // log warn
                        SwingUtilities.invokeLater(new Runnable() { // show message to the user in the UI thread
                            @Override
                            public void run() {
                                JOptionPane.showMessageDialog(null, "Shopping list is not defined\npress EDIT to define it",
                                        "Define Your Shopping List", JOptionPane.WARNING_MESSAGE);
                            }
                        });
                    } else { // database is not empty
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                view.closeHelloScreen(); // close the "HelloScreen"
                                view.showCalculateScreen(); // show the "CalculateScreen"
                            }
                        });
                    }
                } catch (HITFinalProjectException e){
                    e.printStackTrace(); // print error info
                }
            }
        }).start(); // start the thread
    }
}
