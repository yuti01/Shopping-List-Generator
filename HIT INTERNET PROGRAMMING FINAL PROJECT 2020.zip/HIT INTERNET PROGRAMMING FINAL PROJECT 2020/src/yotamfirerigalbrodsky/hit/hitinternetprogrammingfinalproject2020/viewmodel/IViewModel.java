package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.IModel;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view.IView;

/**
 * This interface represents a view-model suitable for this final project
 * a class that implements this interface can be used as the view-model object in this final project
 */
public interface IViewModel {

    /**
     * This method starts this ViewModel object
     */
    public void start();

    /**
     * This method gets a ShoppingList object and then keeps it in the data base
     * @param shoppingList the ShoppingList object to be kept in the data base
     */
    public void keepDataInDB(ShoppingList shoppingList);

    /**
     * sets the View object inside the ViewModel
     * @param v the IView object to be set
     */
    public void setView(IView v);

    /**
     * sets the Model object inside the ViewModel
     * @param m the IModel object to be set
     */
    public void setModel(IModel m);

    /**
     * checks if the data base is empty
     * @return true if the data base is empty or not initialized
     *         false if the data base has some data
     */
    public boolean isDataBaseEmpty();

    /**
     * shows the items the costumer should buy in the result screen
     * @param inStock a ShoppingList object representing the ListProducts the costumer has
     */
    public void showTheShouldBuyList(ShoppingList inStock);

    /**
     * This method manages the transition between the "hello"
     * to the screens coming after in the GUI flow
     */
    public void manageHelloScreenTransition();
}
