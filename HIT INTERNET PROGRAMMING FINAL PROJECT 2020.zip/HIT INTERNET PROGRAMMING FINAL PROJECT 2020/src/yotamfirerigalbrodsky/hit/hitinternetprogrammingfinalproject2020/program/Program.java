package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.program;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Model;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view.View;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.IViewModel;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;


/**
 * This is the driver of the project
 * this class will run its main
 */
public class Program {

    /**
     * The ViewModel object
     * The Logger of this class
     */
    private static IViewModel viewModel;
    private static Logger logger = LogManager.getLogger(Program.class); // init the logger

    /**
     * The main function
     * Start running the program
     * @param args String[] of parameters
     */
    public static void main(String[] args) {

        logger.info("Starting the program - Initializing the ViewModel object"); // logging info

        viewModel = new ViewModel(); // init the ViewModel object
        viewModel.setModel(new Model()); // set the Model object
        viewModel.setView(new View(viewModel)); // set the View object
        viewModel.start(); // start the ViewModel

        /*Model model = new Model();
        model.dropDB(); // dropping the data base */
    }
}
