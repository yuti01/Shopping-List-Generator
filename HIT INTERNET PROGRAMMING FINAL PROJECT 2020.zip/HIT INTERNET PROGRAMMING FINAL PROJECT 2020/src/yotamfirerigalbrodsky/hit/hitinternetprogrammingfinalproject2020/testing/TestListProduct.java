package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.testing;

import org.junit.Assert;
import org.junit.Test;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ListProduct;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;

/*
this is a testing class for the methods of the class: ListProduct
*/

public class TestListProduct {
    /*
    this is the test for the function: getProduct()
     */
    @Test
    public void testGetProduct(){
        //creating a product "milk and using it and the products quantity to create ListProduct
        ListProduct listProduct = new ListProduct(new Product("Toilet Paper"),0);

        String newName = "milk"; // creating the new name of the product in the ListProduct

        Product product = new Product(newName); //creating new Product with the new name

        listProduct.setProduct(product); // changing the Product in the listProduct from milk to Toilet Paper

        // function that Compares the new Product from above and the Product that actually is in the object
        // this time we check if the get function worked
        Assert.assertEquals(product, listProduct.getProduct());
    }

    /*
   this is the test for the function: setProduct()
     */
    @Test
    public void testSetProduct(){
        // creating a product "milk and using it and the products quantity to create ListProduct
        ListProduct listProduct = new ListProduct(new Product("milk"),2);

        String newName = "Toilet Paper"; // creating the new name of the product in the ListProduct

        Product product = new Product(newName); // creating new Product with the new name

        listProduct.setProduct(product); // changing the Product in the listProduct from milk to Toilet Paper

        // function that Compares the new Product from above and the Product that actually is in the object
        // this time we check if the set function worked
        Assert.assertEquals(product, listProduct.getProduct());
    }

    /*
   this is the test for the function: setProductQuantity()
     */
    @Test
    public void testSetProductQuantity(){
        //creating a product "milk and using it and the products quantity to create ListProduct
        ListProduct listProductToTest = new ListProduct(new Product("milk"),2);

        int newQuantity = 4; // store new products quantity

        listProductToTest.setProductQuantity(newQuantity); // using the function we test (set ListProduct)

        // function that Compares the ProductQuantity from above and the quantity that actually is in the object
        Assert.assertEquals(newQuantity, listProductToTest.getProductQuantity());
    }

    /*
   this is the test for the function: getProductQuantity()
     */
    @Test
    public void testGetProductQuantity(){
        int ProductQuantity = 2; // store products quantity

        // creating a product with name "milk" and using it and the products quantity to create ListProduct
        ListProduct listProduct = new ListProduct(new Product("milk"),ProductQuantity);

        //function that Compares the ProductQuantity from above and the result of the function
        // that Supposed to return the product`s quantity
        Assert.assertEquals(ProductQuantity, listProduct.getProductQuantity());
    }
}
