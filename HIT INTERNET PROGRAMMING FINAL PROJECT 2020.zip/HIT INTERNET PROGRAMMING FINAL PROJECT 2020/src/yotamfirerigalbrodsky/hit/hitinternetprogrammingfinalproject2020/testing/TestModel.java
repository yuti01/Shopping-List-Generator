package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.testing;

import org.junit.Assert;
import org.junit.Test;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.exceptions.HITFinalProjectException;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ListProduct;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Model;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;

import java.util.ArrayList;

/*
 this is a testing class for the methods of the class: Model
 !! BE CAREFUL WHEN EXECUTING THE TESTS BELOW !! THEY MAY CHANGE THE DATABASE !!
*/
public class TestModel {

    /*
    this is the test for the function: setShoppingList()
      */
    @Test
    public void testSetShoppingList(){

        Model model = new Model(); // creating a model

        try {
            model.initialize(); // init the database
        }catch (HITFinalProjectException e){} // catch the exception thrown if the database exists

        try { // some method throw an exception
            model.clearDB(); // clearing the database for the testing

            ArrayList<ListProduct> aListOfProducts = new ArrayList<>(); // creating new ArrayList of ListProduct

            // adding to it one ListProduct with the name "Toilet Paper" with the amount of 1
            aListOfProducts.add(new ListProduct(new Product("Toilet Paper"),1));

            // creating a new shoppingList and Initializing it to contain the ArrayList from above
            ShoppingList shoppingList = new ShoppingList(aListOfProducts);

            model.setShoppingList(shoppingList); // using the function we test to set the content of the model

            //Comparing the ShoppingList from above and the content of the database,
            // we get the data from the database by using the function getShoppingList that we test later
            Assert.assertEquals(shoppingList,model.getShoppingList());
        } catch (HITFinalProjectException e) {
            e.printStackTrace(); // print the error details
            Assert.assertEquals(1,0); // make the test fail
        }
    }

    /*
   this is the test for the function: getShoppingList()
     */
    @Test
    public void testGetShoppingList(){
        Model model = new Model(); // creating a model

        try {
            model.initialize(); // init the database
        }catch (HITFinalProjectException e){} // catch the exception thrown if the database exists

        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        // adding to it one ListProduct: Toilet Paper with the amount of 1
        listOfProducts1.add(new ListProduct(new Product("Toilet Paper"),1));

        // creating new shoppingList and Initializing it to contain the ArrayList from above
        ShoppingList shoppingList = new ShoppingList(listOfProducts1);

        try { // some of the lines below may throw an exception

            // using the function we tested earlier to set the content of the database
            model.setShoppingList(shoppingList);

            // Comparing the ShoppingList from above and the content of the database,
            // we get the content of the database by using the function getShoppingList that we test now
            Assert.assertEquals(shoppingList,model.getShoppingList());
        } catch (HITFinalProjectException e) {
            e.printStackTrace(); // print the error details
            Assert.assertEquals(1,0); // make the test fail
        }
    }

    /*
    this is the test for the function: isEmpty()
    */
    @Test
    public void testIsEmpty(){
        Model model = new Model(); // creating a model

        try {
            model.initialize(); // init the database
        }catch (HITFinalProjectException e){} // catch the exception thrown if the database exists

        try {
            model.clearDB(); // clearing the database
            // now the database is empty

            // Testing if "isEmpty" returned true as expected
            Assert.assertTrue(model.isEmpty());
        } catch (HITFinalProjectException e) {
            e.printStackTrace(); // print the error details
            Assert.assertEquals(1,0); // make the test fail
        }
    }

    /*
    this is the test for the function: clearDB()
    */
    @Test
    public void testClearDB(){
        Model model = new Model(); // creating a model

        try {
            model.initialize(); // init the database
        }catch (HITFinalProjectException e){} // catch the exception thrown if the database exists

        try {
            // adding items to a ShoppingList
            ShoppingList aShoppingList = new ShoppingList(); // the ShoppingList to be sent to the database
            aShoppingList.add(new ListProduct(new Product("milk"),5));
            aShoppingList.add(new ListProduct(new Product("egg"),2));
            aShoppingList.add(new ListProduct(new Product("bread"),4));

            // now lets add the ShoppingList to the database
            model.setShoppingList(aShoppingList);

            // now the database contains three items

            model.clearDB(); // clearing the database
            // now the database is empty

            // Testing if "isEmpty" returned true as expected
            Assert.assertTrue(model.isEmpty());

            /* we are testing "clearDB" by using "isEmpty" */
        } catch (HITFinalProjectException e) {
            e.printStackTrace(); // print the error details
            Assert.assertEquals(1,0); // make the test fail
        }
    }
}
