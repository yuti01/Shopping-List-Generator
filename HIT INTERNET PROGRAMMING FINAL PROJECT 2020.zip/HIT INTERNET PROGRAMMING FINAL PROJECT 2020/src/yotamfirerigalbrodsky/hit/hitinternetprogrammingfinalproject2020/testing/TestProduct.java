package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.testing;

import org.junit.Assert;
import org.junit.Test;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;

/* Testing the Product class */

public class TestProduct {
    @Test
    public void getProductName() {
        Product testProduct = new Product("milk"); // create a new Product with a name

        String actualName = "milk"; // store the actual name of Product

        Assert.assertEquals(actualName ,testProduct.getProductName()); // Test if they are equal
    }

    @Test
    public void setProductName() {
        Product testProduct = new Product(""); // create a new Product without a name

        String newActualName = "milk"; // store the name to set

        testProduct.setProductName(newActualName); // set it

        Assert.assertEquals(newActualName, testProduct.getProductName()); // Test if they are equal
    }

    @Test
    public void testEquals() {
        Product product1 = new Product("milk"); // milk product
        Product product2 = new Product("milk"); // milk product
        Product product3 = new Product("egg"); // egg product

        Assert.assertTrue(product1.equals(product2)); // product1 = product2 ?

        Assert.assertTrue(product2.equals(product1)); // product2 = product1 ?

        Assert.assertFalse(product1.equals(product3)); // product1 != product3 ?

        Assert.assertFalse(product3.equals(product1)); // product3 != product1 ?
    }

    @Test
    public void testToString() {
        Product testProduct = new Product("milk"); // create a new Product without a name

        String actualToString = "milk"; //store the actual toString String

        Assert.assertEquals(actualToString, testProduct.toString()); // Test if they are equal
    }
}
