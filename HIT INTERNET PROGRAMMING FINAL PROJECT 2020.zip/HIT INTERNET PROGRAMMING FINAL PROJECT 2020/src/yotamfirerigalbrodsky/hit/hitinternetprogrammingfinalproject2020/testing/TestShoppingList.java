package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.testing;

import org.junit.Assert;
import org.junit.Test;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ListProduct;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;

import java.util.ArrayList;

/*
 this is a testing class for the methods of the class: ShoppingList
*/
public class TestShoppingList {

    /*
     this is the test for the function: SetListOfProduct()
     */
    @Test
    public void testSetListOfProduct(){
        ArrayList<ListProduct> listOfProducts = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct = new ListProduct(new Product("milk"),4);

        listOfProducts.add(listProduct); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList = new ShoppingList(); // creating new ShoppingList

        //setting the shoppingList with the ArrayList: listOfProducts , this is the function we are testing
        shoppingList.setListOfProducts(listOfProducts);

        // creating another ListProduct
        ListProduct otherListProduct = new ListProduct(new Product("milk"),4);

        ShoppingList otherShoppingList = new ShoppingList(); // creating second ShoppingList

        otherShoppingList.add(otherListProduct); // adding the listProduct to the listOfProducts

        Assert.assertEquals(shoppingList,otherShoppingList); // compare shoppingList and otherShoppingList
    }

    /*
    this is the test for the function: GetListOfProduct()
     */
    @Test
    public void testGetListOfProduct(){
        ArrayList<ListProduct> listOfProducts = new ArrayList<>();//creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct = new ListProduct(new Product("milk"),4);

        listOfProducts.add(listProduct);//adding the listProduct to the listOfProducts

        ShoppingList shoppingList = new ShoppingList();//creating new ShoppingList

        shoppingList.setListOfProducts(listOfProducts);//setting the shoppingList with the ArrayList: listOfProducts

        //creating second ListProduct using the Product milk and the Quantity 4
        ListProduct listProduct1 = new ListProduct(new Product("milk"),4);

        ShoppingList otherShoppingList = new ShoppingList(); // creating new ShoppingList

        otherShoppingList.add(listProduct1); // adding the listProduct to the listOfProducts

        Assert.assertEquals(shoppingList,otherShoppingList); // compare shoppingList and otherShoppingList
    }

    /*
    this is the test for the function: Add()
    */
    @Test
    public void testAdd() {
        String theNameForTheNewItem = "egg"; // creating new string: "egg" representing the name of the new item

        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct1 = new ListProduct(new Product(theNameForTheNewItem),4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList

        shoppingList1.add(listProduct1); // adding the listProduct to  shoppingList1

        ArrayList<ListProduct> listOfProducts2 = new ArrayList<>(); // creating second ArrayList of ListProduct

        // creating second ListProduct using the Product milk and the Quantity 4
        ListProduct listProduct2 = new ListProduct(new Product(theNameForTheNewItem),4);

        ShoppingList shoppingList2 = new ShoppingList(); // creating second ShoppingList

        shoppingList2.add(listProduct2); // adding the listProduct to shoppingList2

        Assert.assertEquals(shoppingList1.getCopy(),shoppingList2.getCopy()); // compare shoppingList1 and shoppingList2
    }

    /*
    this is the test for the function: SetListOfProduct()
         */
    @Test
    public void TestAddByIndex(){

        ShoppingList theShoppingList = new ShoppingList(); // create a ShoppingList object

        // add some items to the List created above (using the simple add method)
        theShoppingList.add(new ListProduct(new Product("milk"),5)); // #0
        theShoppingList.add(new ListProduct(new Product("milk"),5)); // #1
        theShoppingList.add(new ListProduct(new Product("milk"),5)); // #2
        theShoppingList.add(new ListProduct(new Product("milk"),5)); // #3
        theShoppingList.add(new ListProduct(new Product("milk"),5)); // #4

        // adding a new ListProduct in in index 3 with the tested method
        theShoppingList.add(3, new ListProduct(new Product("egg"),20));

        // now let`s create another ShoppingList
        // this List should be the same as the first one
        ShoppingList expectedShoppingList = new ShoppingList();

        // adding the Products
        expectedShoppingList.add(new ListProduct(new Product("milk"),5)); // #0
        expectedShoppingList.add(new ListProduct(new Product("milk"),5)); // #1
        expectedShoppingList.add(new ListProduct(new Product("milk"),5)); // #2

        // the item added by index earlier
        expectedShoppingList.add(new ListProduct(new Product("egg"),20)); // #3

        expectedShoppingList.add(new ListProduct(new Product("milk"),5)); // #4
        expectedShoppingList.add(new ListProduct(new Product("milk"),5)); // #5

        Assert.assertEquals(expectedShoppingList,theShoppingList); // Test if the two ShoppingLists are equal
    }

    /*
    this is the test for the function: AddAll()
         */
    @Test
    public void testAddAll(){
        String itemName = "egg"; // creating new string: "egg"

        String newItemName = "milk"; // creating new string: "milk"

        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct1 = new ListProduct(new Product(itemName),4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList

        shoppingList1.setListOfProducts(listOfProducts1); // setting shoppingList1 with the ArrayList: listOfProducts1

        ArrayList<ListProduct> listOfProducts2 = new ArrayList<>(); // creating second ArrayList of ListProduct

        ListProduct listProduct2 = new ListProduct(new Product(newItemName),4); // creating second ListProduct using the Product milk and the Quantity 4

        listOfProducts2.add(listProduct2); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList2 = new ShoppingList(); // creating second ShoppingList

        shoppingList2.setListOfProducts(listOfProducts2); // setting shoppingList2 with the ArrayList: listOfProducts2

        ArrayList<ListProduct> listOfProducts3 = new ArrayList<>(); // creating third ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct3 = new ListProduct(new Product(itemName),4);

        listOfProducts3.add(listProduct3); // adding the listProduct(3) to the listOfProducts(3)

        listOfProducts3.add(listProduct2); // adding the listProduct(2) to the listOfProducts(3)

        ShoppingList shoppingList3 = new ShoppingList(); // creating third ShoppingList

        shoppingList3.setListOfProducts(listOfProducts3); // setting shoppingList3 with the ArrayList: listOfProducts3

        shoppingList1.addAll(shoppingList2); // add from shoppingList2 into shoppingList1

        // now they should contain th same ListProducts

        Assert.assertEquals(shoppingList1,shoppingList3); // compare shoppingList1 and otherShoppingList3, we added  shoppingList1 and shoppingList2
    }

    /*
    this is the test for the function: GetCopy()
         */
    @Test
    public void testGetCopy(){
        String itemName = "egg"; // creating new string: "egg"

        String newItemName = "milk"; // creating new string: "milk"

        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        // creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct1 = new ListProduct(new Product(itemName),4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts
        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList
        shoppingList1.setListOfProducts(listOfProducts1); // setting shoppingList1 with the ArrayList: listOfProducts1

        ArrayList<ListProduct> listOfProducts2 = new ArrayList<>(); // creating second ArrayList of ListProduct

        // creating second ListProduct using the Product with name "milk" and the Quantity 4
        ListProduct listProduct2 = new ListProduct(new Product(newItemName),4);

        listOfProducts2.add(listProduct2); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList2 = new ShoppingList(); // creating second ShoppingList

        shoppingList2.setListOfProducts(listOfProducts2); // setting shoppingList2 with the ArrayList: listOfProducts2

        shoppingList2 = shoppingList1.getCopy();

        Assert.assertEquals(shoppingList1,shoppingList2); // compare shoppingList1 and otherShoppingList2
    }

    /*
    this is the test for the function: ContainsByProduct()
     */
    @Test
    public void testContainsByProduct(){
        Product product = new Product("egg"); // creating a new Product

        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct1 = new ListProduct(product,4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList

        shoppingList1.setListOfProducts(listOfProducts1); // setting shoppingLis1t with the ArrayList: listOfProducts1

        Assert.assertTrue(shoppingList1.contains(product)); // checking if the shoppingList1 contains product ("egg",4)
    }

    /*
    this is the test for the function: ContainsByListProduct()
     */
    @Test
    public void  testContainsByListProduct() {
        ArrayList<ListProduct> theListOfProducts = new ArrayList<>(); // creating new ArrayList of ListProduct

        // creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct aListProduct = new ListProduct(new Product("egg"),4);

        theListOfProducts.add(aListProduct); // adding the listProduct to the listOfProducts

        ShoppingList theShoppingList = new ShoppingList(); // creating new ShoppingList

        //setting theShoppingList with the ArrayList: theListOfProducts
        theShoppingList.setListOfProducts(theListOfProducts);

        System.out.println("the ShoppingList:");
        System.out.println(theShoppingList.toString());

        // checking if the theShoppingList contains aListProduct ("egg", 4)
        Assert.assertTrue(theShoppingList.contains(aListProduct));
    }

    /*
    this is the test for the function: IsEmpty()
     */
    @Test
    public void testIsEmpty(){
        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        // creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct aListProduct = new ListProduct(new Product("egg"),4);

        listOfProducts1.add(aListProduct); // adding the listProduct to the listOfProducts

        ShoppingList theShoppingList = new ShoppingList(); // creating new ShoppingList

        // setting theShoppingList with the ArrayList: listOfProducts1
        theShoppingList.setListOfProducts(listOfProducts1);

        //checking if the theShoppingList is Empty using the function we test: isEmpty()
        Assert.assertFalse(theShoppingList.isEmpty());

        // checking if the isEmpty method returns "true" for an empty ShoppingList
        Assert.assertTrue((new ShoppingList()).isEmpty());
    }

    /*
    this is the test for the function: GetListProductByIndex()
     */
    @Test
    public void testGetListProductByIndex(){
        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "egg" and the Quantity 4
        ListProduct listProduct1 = new ListProduct(new Product("egg"),4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList

        shoppingList1.setListOfProducts(listOfProducts1); // setting shoppingList1 with the ArrayList: listOfProducts1

        ShoppingList shoppingList = new ShoppingList(); // creating second ShoppingList
        shoppingList.add(shoppingList1.get(0)); // adding the listProduct to the listOfProducts

        Assert.assertEquals(shoppingList, shoppingList1); // checking if shoppingList is the same as shoppingList1

    }

    /*
    this is the test for the function: GetListProductByProduct()
     */
    @Test
    public void testGetListProductByProduct(){
        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        Product product = new Product("egg"); // creating new product that is Item

        // creating new ListProduct using the Product milk and the Quantity 4
        ListProduct listProduct1 = new ListProduct(product,4);

        listOfProducts1.add(listProduct1); // adding the listProduct to the listOfProducts

        // creating new ShoppingList and Initializing with listOfProducts1
        ShoppingList shoppingList1 = new ShoppingList(listOfProducts1);

        ShoppingList shoppingList = new ShoppingList(); // creating second ShoppingList
        shoppingList.add(shoppingList1.get(product)); // adding the listProduct to the listOfProducts
        Assert.assertEquals(shoppingList, shoppingList1); // checking if shoppingList is the same as shoppingList1
    }

    /*
    this is the test for the function: equals()
     */
    @Test
    public void testEquals(){
        ArrayList<ListProduct> listOfProducts1 = new ArrayList<>(); // creating new ArrayList of ListProduct

        //creating new ListProduct using the Product with name "milk" and the Quantity 4
        ListProduct listProduct = new ListProduct(new Product("milk"),4);

        listOfProducts1.add(listProduct); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList1 = new ShoppingList(); // creating new ShoppingList

        shoppingList1.setListOfProducts(listOfProducts1); // setting shoppingList1 with the ArrayList: listOfProducts1

        ArrayList<ListProduct> listOfProducts2 = new ArrayList<>(); // creating second ArrayList of ListProduct

        // creating second ListProduct using the Product milk and the Quantity 4
        ListProduct listProduct2 = new ListProduct(new Product("milk"),4);

        listOfProducts2.add(listProduct); // adding the listProduct to the listOfProducts

        ShoppingList shoppingList2 = new ShoppingList(listOfProducts2); // creating second ShoppingList and Initializing with listOfProducts2

        // checking if shoppingList2 is the same as shoppingList1,
        // we use the function equals, it suppose to return true if they equal
        Assert.assertTrue(shoppingList1.equals(shoppingList2));
    }

    /*
    this is the test for the method: remainsToBuy()
     */
    @Test
    public void testRemainsToBuy(){
        // creating the ShoppingLists
        ShoppingList inStock = new ShoppingList();
        ShoppingList shouldHave = new ShoppingList();

        // Adding some items to the inStock ShoppingList
        inStock.add(new ListProduct(new Product("egg"),10));
        inStock.add(new ListProduct(new Product("lollipop"),5));

        // Adding some items to the shouldHave ShoppingList
        shouldHave.add(new ListProduct(new Product("egg"),20));
        shouldHave.add(new ListProduct(new Product("lollipop"),5));
        shouldHave.add(new ListProduct(new Product("bread"),2));

        // creating the result of the subtraction
        ShoppingList resultList = new ShoppingList();

        // Adding the items of the result ShoppingList
        resultList.add(new ListProduct(new Product("egg"),10));
        resultList.add(new ListProduct(new Product("bread"),2));

        // Test if the static method "remainsToBuy" is returning the expected result
        Assert.assertEquals(resultList,ShoppingList.remainsToBuy(shouldHave,inStock));
    }

    /*
    this is the test for the method: toMatrix()
     */
    @Test
    public void testToMatrix(){
        // creating a ShoppingList
        ShoppingList aShoppingList = new ShoppingList();

        // Add some items to this List
        aShoppingList.add(new ListProduct(new Product("egg"),10));
        aShoppingList.add(new ListProduct(new Product("milk"),2));
        aShoppingList.add(new ListProduct(new Product("butter"),3));

        // creating the expected ShoppingList
        Object[][] theMatrix = {{"egg",10},{"milk",2},{"butter",3}};

        Assert.assertEquals(theMatrix,aShoppingList.toMatrix());
    }
}
