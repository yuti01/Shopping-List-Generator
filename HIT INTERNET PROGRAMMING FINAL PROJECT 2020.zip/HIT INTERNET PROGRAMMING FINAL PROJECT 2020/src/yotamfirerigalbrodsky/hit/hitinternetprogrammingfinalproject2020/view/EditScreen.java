package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents the screen on which the user edits his shopping list
 * It has a Table, label and 3 Buttons
 */
public class EditScreen {

    /**
     * view is the View (IView interface) object that created this instance of the class
     * editFrame is the Frame of this screen
     * editTablePanel is the panel in which the big Table lays
     * editUpperPanel is the panel in which a label and a button reside
     * editButtonsPanel is the panel in which save and cancel buttons reside
     * editLabel is a label with some text to the user
     * editAddNewItemButton is a button to add a new item to the table
     * editCancelButton is a button to cancel the operation
     * editSaveButton is a button to save the new shopping list (completing the operation)
     * editTable is the table in which the user will see the items
     * editTableScroller is a scroller to be added to the table above
     * logger is the logger of this class
     */
    private IView view; // The view that created this instance of the class

    private JFrame editFrame; // The Frame of this screen

    // Three panels - the first one is for the big Table in this Frame
    //                the second one is for a label and a button (add item)
    //                the third one is for the 2 buttons (save and cancel)
    private JPanel editTablePanel;
    private JPanel editUpperPanel;
    private JPanel editButtonsPanel;

    private JLabel editLabel; // a label to show some text for the user

    // Three buttons - the first one is for adding a new item to the table
    //                 the second one is for canceling the operation
    //                 the third one is for saving the new shopping list (completing the operation)
    private JButton editAddNewItemButton;
    private JButton editCancelButton;
    private JButton editSaveButton;

    private JTable editTable; // The Table in which the user will see the items

    private JScrollPane editTableScroller; // a scroller to be added to the table above

    private Logger logger = LogManager.getLogger(EditScreen.class); // init the logger

    /**
     * The constructor of this class
     *
     * @param view the view that created this instance of the class
     */
    public EditScreen(IView view) {

        logger.info("creating the 'edit screen' to show"); // log info

        // initializing every object

        this.view = view; // set the view

        editFrame = new JFrame("Shopping List Calculator"); // create the JFrame with a title
        // create the panels
        editTablePanel = new JPanel();
        editUpperPanel = new JPanel();
        editButtonsPanel = new JPanel();
        editLabel = new JLabel("Your Shopping List"); // create the label
        // Table initializing:
        String[] colHeadings = {"NAME", "QUANTITY"};
        int numRows = 0;
        DefaultTableModel model = new DefaultTableModel(numRows, colHeadings.length);
        model.setColumnIdentifiers(colHeadings);
        editTable = new JTable(model);
        // END of Table initializing

        editTableScroller = new JScrollPane(editTable); // initialize scroller

        // initialize the buttons:
        editAddNewItemButton = new JButton("+");
        editSaveButton = new JButton("Save");
        editCancelButton = new JButton("Cancel");

        // Basic components settings:

        editAddNewItemButton.setPreferredSize(new Dimension(50, 30));
        editSaveButton.setPreferredSize(new Dimension(200, 50));
        editCancelButton.setPreferredSize(new Dimension(200, 50));

        editLabel.setFont(new Font("Cooper Black", Font.ROMAN_BASELINE, 20));
        editAddNewItemButton.setFont(new Font("Cooper Black", Font.PLAIN, 20));
        editSaveButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));
        editCancelButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));
        editAddNewItemButton.setBackground(Color.YELLOW);
        editSaveButton.setBackground(Color.YELLOW);
        //editCancelButton.setBackground(Color.red);

        // Adding Action Listeners to the Buttons:

        editAddNewItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Creating a JPanel full of components to show in the confirm dialog of the JOptionPane

                // Two Text Fields
                JTextField nameField = new JTextField(10);
                JTextField quantityField = new JTextField(10);

                // Adding them with corresponding labels
                JPanel inputPanel = new JPanel();
                inputPanel.add(new JLabel("Name:"));
                inputPanel.add(nameField);
                inputPanel.add(new JLabel("Quantity:"));
                inputPanel.add(quantityField);

                // Keep the button that the user clicked (as int)
                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter the name and the quantity of the new item", JOptionPane.OK_CANCEL_OPTION);


                if (result == JOptionPane.OK_OPTION) { // user clicked OK (otherwise, he canceled)

                    // check if the user actually entered some data
                    if (nameField.getText() == null || quantityField.getText() == null ||
                            nameField.getText().equals("") || quantityField.getText().equals("")) {

                        // show error message
                        JOptionPane.showMessageDialog(null, "You Should enter some data", "Input Error", JOptionPane.ERROR_MESSAGE);
                        logger.warn("user tried to add an item without its name or its quantity");
                    } else {
                        if (!quantityField.getText().matches("[0-9]+")) { // input validation
                            // show error message
                            JOptionPane.showMessageDialog(null, "You should enter an integer to the quantity field", "Input Error", JOptionPane.ERROR_MESSAGE);
                            logger.warn("user tried to add an item with a wrong quantity format");
                        } else {
                            ShoppingList shoppingList = ShoppingList.tableToShoppingList(editTable); // get the shopping list from the table

                            if (shoppingList != null && shoppingList.contains(new Product(nameField.getText()))) { // check if the user tried to add a Product that is already entered
                                JOptionPane.showMessageDialog(null, "You have already entered this product", "Input Error", JOptionPane.ERROR_MESSAGE);
                                logger.warn("user tried to add an item that was already added");

                            } else {
                                // get the data from the text fields
                                String name = nameField.getText();
                                int quantity = Integer.parseInt(quantityField.getText());

                                // add the new row to the table model
                                DefaultTableModel model = (DefaultTableModel) editTable.getModel();
                                model.addRow(new Object[]{name, quantity});

                                logger.info("row added {" + name + ", " + quantity + "}");
                            }
                        }
                    }
                }
            }
        });

        editSaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                logger.info("saving new shopping list"); // log info

                ShoppingList shoppingList = ShoppingList.tableToShoppingList(editTable); // get the shopping list from the table
                if (shoppingList != null) {
                    view.sendData(shoppingList); // send to the data base

                    logger.info("saving new list"); // log info

                    DefaultTableModel tableModel = (DefaultTableModel) editTable.getModel(); // get the table model
                    tableModel.setRowCount(0); // clear the table by setting the row count to 0
                    editFrame.setVisible(false); // disappear
                    view.showHelloScreen(); // back to main menu
                } else {
                    logger.warn("the user tried to save an empty list"); // log warn

                    JOptionPane.showMessageDialog(null, "You have to add at least one item"
                            , "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        editCancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("operation canceled"); // log info

                JOptionPane.showMessageDialog(null, "Operation canceled");
                //editTable.setModel(new DefaultTableModel()); // clear the table by setting a new model

                DefaultTableModel tableModel = (DefaultTableModel) editTable.getModel();
                tableModel.setRowCount(0); // clear the table by setting the row count to 0
                editFrame.setVisible(false); // disappear
                view.showHelloScreen(); // show hello screen
            }
        });

        // Panels settings:

        editTablePanel.setLayout(new BorderLayout());
        editUpperPanel.setLayout(new BoxLayout(editUpperPanel, BoxLayout.LINE_AXIS));
        editButtonsPanel.setLayout(new FlowLayout());

        // Add to the Panels

        editTablePanel.add(editTableScroller);

        editUpperPanel.add(Box.createRigidArea(new Dimension(15, 0)));
        editUpperPanel.add(editLabel);
        editUpperPanel.add(Box.createHorizontalGlue());
        editUpperPanel.add(editAddNewItemButton);
        editUpperPanel.add(Box.createRigidArea(new Dimension(15, 0)));
        ;

        editButtonsPanel.add(editSaveButton);

        editButtonsPanel.add(editCancelButton);

        // Frame settings:

        editFrame.setPreferredSize(new Dimension(500, 300));
        editFrame.setLayout(new BorderLayout());

        // Add to the Frame
        editFrame.add(editTablePanel, BorderLayout.CENTER);
        editFrame.add(editUpperPanel, BorderLayout.NORTH);
        editFrame.add(editButtonsPanel, BorderLayout.SOUTH);
        editFrame.add(new JLabel("    "), BorderLayout.EAST);
        editFrame.add(new JLabel("    "), BorderLayout.WEST);

        // Add closing settings:
        editFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    /**
     * Start showing this screen
     */
    public void go() {
        editFrame.pack(); // pack the frame
        editFrame.setVisible(true); // show the frame
        logger.info("'edit screen' is visible"); // log info
    }

}
