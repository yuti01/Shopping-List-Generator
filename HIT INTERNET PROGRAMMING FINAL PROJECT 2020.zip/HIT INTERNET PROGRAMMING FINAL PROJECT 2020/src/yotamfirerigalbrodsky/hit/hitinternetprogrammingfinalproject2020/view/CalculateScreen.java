package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.Product;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents the calculation screen
 * where the user can calculate the list of items he need to buy
 * It has a Table, label and 3 Buttons
 */
public class CalculateScreen {

    /**
     * view is the View (IView interface) object that created this instance of the class
     * calcFrame is the Frame of this screen
     * calcTablePanel is the panel in which the big Table lays
     * calcUpperPanel is the panel in which a label and a button reside
     * calcButtonsPanel is the panel in which calculate and cancel buttons reside
     * calcLabel is a label with some text to the user
     * calcAddNewItemButton is a button to add a new item to the table
     * calcCancelButton is a button to cancel the operation
     * calcCalculateButton is a button to show the result screen (complete the operation)
     * calcTable is the table in which the user will see the items
     * calcTableScroller is a scroller to be added to the table above
     * logger is the logger of this class
     */
    private IView view; // The view that created this instance of the class

    private JFrame calcFrame; // The Frame of this screen

    // Three panels - the first one is for the big Table in this Frame
    //                the second one is for a label and a button (add item)
    //                the third one is for the 2 buttons (calculate and cancel)
    private JPanel calcTablePanel;
    private JPanel calcUpperPanel;
    private JPanel calcButtonsPanel;

    private JLabel calcLabel; // a label to show some text for the user

    // Three buttons - the first one is for adding a new item to the table
    //                 the second one is for canceling the operation
    //                 the third one is for showing the result screen (completing the operation)
    private JButton calcAddNewItemButton;
    private JButton calcCancelButton;
    private JButton calcCalculateButton;

    private JTable calcTable; // The Table in which the user will see the items

    private JScrollPane calcTableScroller; // a scroller to be added to the table above

    private Logger logger = LogManager.getLogger(CalculateScreen.class); // init the logger

    /**
     * The constructor of this class
     *
     * @param view the view that created this instance of the class
     */
    public CalculateScreen(IView view) {

        logger.info("creating the 'calculate screen' to show"); // log info

        // initializing every object

        this.view = view; // set the view

        calcFrame = new JFrame("Shopping List Calculator"); // create the JFrame with a title

        // create the panels
        calcTablePanel = new JPanel();
        calcUpperPanel = new JPanel();
        calcButtonsPanel = new JPanel();
        calcLabel = new JLabel("What you have got"); // create the label

        // Table initializing:
        String[] colHeadings = {"NAME", "QUANTITY"};
        int numRows = 0;
        DefaultTableModel model = new DefaultTableModel(numRows, colHeadings.length);
        model.setColumnIdentifiers(colHeadings);
        calcTable = new JTable(model);
        // END of Table initializing

        calcTableScroller = new JScrollPane(calcTable); // initialize scroller

        // initialize the buttons:
        calcAddNewItemButton = new JButton("+");
        calcCalculateButton = new JButton("Calculate");
        calcCancelButton = new JButton("Cancel");

        // Basic components settings:

        calcAddNewItemButton.setPreferredSize(new Dimension(50, 30));
        calcCalculateButton.setPreferredSize(new Dimension(200, 50));
        calcCancelButton.setPreferredSize(new Dimension(200, 50));

        calcLabel.setFont(new Font("Cooper Black", Font.ROMAN_BASELINE, 20));
        calcAddNewItemButton.setFont(new Font("Cooper Black", Font.PLAIN, 20));
        calcCalculateButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));
        calcCancelButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));
        calcAddNewItemButton.setBackground(Color.YELLOW);
        calcCalculateButton.setBackground(Color.YELLOW);
        //calcCancelButton.setBackground(Color.RED);

        // Adding Action Listeners to the Buttons:

        calcAddNewItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Creating a JPanel full of components to show in the confirm dialog of the JOptionPane

                // Two Text Fields
                JTextField nameField = new JTextField(10);
                JTextField quantityField = new JTextField(10);

                // Adding them with corresponding labels
                JPanel inputPanel = new JPanel();
                inputPanel.add(new JLabel("Name:"));
                inputPanel.add(nameField);
                inputPanel.add(new JLabel("Quantity:"));
                inputPanel.add(quantityField);

                // Keep the button that the user clicked (as int)
                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter the name and the quantity of the new item", JOptionPane.OK_CANCEL_OPTION);


                if (result == JOptionPane.OK_OPTION) { // user clicked OK (otherwise, he canceled)

                    // check if the user actually entered some data
                    if (nameField.getText() == null || quantityField.getText() == null ||
                            nameField.getText().equals("") || quantityField.getText().equals("")) {

                        // show error message
                        JOptionPane.showMessageDialog(null, "You Should enter some data", "Input Error", JOptionPane.ERROR_MESSAGE);
                        logger.warn("user tried to add an item without its name or its quantity");
                    } else {
                        if (!quantityField.getText().matches("[0-9]+")) { // input validation
                            // show error message
                            JOptionPane.showMessageDialog(null, "You should enter an integer to the quantity field", "Input Error", JOptionPane.ERROR_MESSAGE);
                            logger.warn("user tried to add an item with a wrong quantity format");
                        }else{
                            ShoppingList shoppingList = ShoppingList.tableToShoppingList(calcTable); // get the shopping list from the table

                            if (shoppingList != null && shoppingList.contains(new Product(nameField.getText()))) { // check if the user tried to add a Product that is already entered
                                JOptionPane.showMessageDialog(null, "You have already entered this product", "Input Error", JOptionPane.ERROR_MESSAGE);
                                logger.warn("user tried to add an item that was already added");

                            }
                            else {
                                // get the data from the text fields
                                String name = nameField.getText();
                                int quantity = Integer.parseInt(quantityField.getText());

                                // add the new row to the table model
                                DefaultTableModel model = (DefaultTableModel) calcTable.getModel();
                                model.addRow(new Object[]{name, quantity});

                                logger.info("row added {" + name + ", " + quantity + "}");
                            }
                        }
                    }
                }
            }
        });

        calcCalculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("calculating the results"); // log info

                ShoppingList inStock = ShoppingList.tableToShoppingList(calcTable); // get the shopping list from the table

                if (inStock == null) logger.warn("the user didn't add some items"); // log warn if the table is empty

                // # ShoppingList shouldHave = view.getData(); // get the shopping list from the data base
                //calcTable.setModel(new DefaultTableModel()); // clear the table by setting a new model
                DefaultTableModel tableModel = (DefaultTableModel) calcTable.getModel();
                tableModel.setRowCount(0); // clear the table by setting the row count to 0
                calcFrame.setVisible(false); // disappear

                // calculate the result and show in the result screen
                // # view.showResultScreen(ShoppingList.remainsToBuy(shouldHave,inStock));

                // # new version # //

                view.showResultScreen();
                view.showItemsInResultScreenTable(inStock);
            }
        });

        calcCancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("operation canceled"); // log info

                JOptionPane.showMessageDialog(null, "Operation canceled");
                //calcTable.setModel(new DefaultTableModel()); // clear the table by setting a new model
                DefaultTableModel tableModel = (DefaultTableModel) calcTable.getModel();
                tableModel.setRowCount(0); // clear the table by setting the row count to 0
                calcFrame.setVisible(false); // disappear
                view.showHelloScreen(); // show hello screen
            }
        });

        // Panels settings:
        // (set layouts)

        calcTablePanel.setLayout(new BorderLayout());
        calcUpperPanel.setLayout(new BoxLayout(calcUpperPanel, BoxLayout.LINE_AXIS));
        calcButtonsPanel.setLayout(new FlowLayout());

        // Add to the Panels

        calcTablePanel.add(calcTableScroller); // Add the scroller

        calcUpperPanel.add(Box.createRigidArea(new Dimension(15, 0))); // A spacer
        calcUpperPanel.add(calcLabel); // Add the label
        calcUpperPanel.add(Box.createHorizontalGlue()); // GLue the components in this panel to the sides
        calcUpperPanel.add(calcAddNewItemButton); // Add the button
        calcUpperPanel.add(Box.createRigidArea(new Dimension(15, 0))); // A spacer

        calcButtonsPanel.add(calcCalculateButton); // Add the button

        calcButtonsPanel.add(calcCancelButton); // Add the button

        // Frame settings:

        calcFrame.setPreferredSize(new Dimension(500, 300)); // set the size of the frame
        calcFrame.setLayout(new BorderLayout()); // set the layout of the frame

        // Add to the Frame
        calcFrame.add(calcTablePanel, BorderLayout.CENTER);
        calcFrame.add(calcUpperPanel, BorderLayout.NORTH);
        calcFrame.add(calcButtonsPanel, BorderLayout.SOUTH);
        calcFrame.add(new JLabel("    "), BorderLayout.EAST); // Spacer
        calcFrame.add(new JLabel("    "), BorderLayout.WEST); // Spacer

        // Add closing settings:
        calcFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    /**
     * Start showing this screen
     */
    public void go() {
        calcFrame.pack(); // pack the frame
        calcFrame.setVisible(true); // show it
        logger.info("'calculate screen' is visible"); // log info
    }

}
