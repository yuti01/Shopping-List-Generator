package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ListProduct;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents the Result screen - the final screen of a normal calculation flow
 * It has a label, a table and one button
 */
public class ResultScreen {

    /**
     * view is the View (IView interface) object that created this instance of the class
     * resFrame is the Frame of this screen
     * resTablePanel is the panel in which the big Table lays
     * resUpperPanel is the panel in which a label reside
     * resButtonsPanel is the panel in which backToMainMenu button reside
     * resLabel is a label with some text to the user
     * resBackToMainMenuButton is a button to add a new item to the table
     * logger is the logger of this class
     */
    private IView view; // The view that created this instance of the class

    private JFrame resFrame; // The Frame of this screen

    // Three panels - the first one is for the big Table in this Frame
    //                the second one is for a label
    //                the third one is for the  button (back to main menu)
    private JPanel resTablePanel;
    private JPanel resUpperPanel;
    private JPanel resButtonsPanel;

    private JLabel resLabel; // a label to show some text for the user

    private JButton resBackToMainMenuButton; // A button to get back to the main menu

    private JTable resTable; // The Table in which the user will see the items

    private JScrollPane resTableScroller; // a scroller to be added to the table above

    private Logger logger = LogManager.getLogger(ResultScreen.class); // init the logger

    /**
     * The constructor of this class
     * @param view the view that created this instance of the class
     */
    public ResultScreen(IView view) {

        logger.info("creating the 'result screen' to show"); // log info

        // initializing every object

        this.view = view; // set the view

        resFrame = new JFrame("Shopping List Calculator"); // create the JFrame with a title

        // create the panels
        resTablePanel = new JPanel();
        resUpperPanel = new JPanel();
        resButtonsPanel = new JPanel();

        resLabel = new JLabel("You need to buy"); // create the label

        //Table initializing:
        String[] colHeadings = {"NAME","QUANTITY"};
        int numRows = 0 ;
        DefaultTableModel model = new DefaultTableModel(numRows, colHeadings.length) ;
        model.setColumnIdentifiers(colHeadings);
        resTable = new JTable(model);
        // END of Table initializing

        resTableScroller = new JScrollPane(resTable); // initialize scroller

        // initialize the button:
        resBackToMainMenuButton = new JButton("OK");

        // Basic components settings:

        resBackToMainMenuButton.setPreferredSize(new Dimension(200,50));
        resBackToMainMenuButton.setFont(new Font("Cooper Black", Font.ROMAN_BASELINE,30));
        resBackToMainMenuButton.setBackground(Color.YELLOW);

        resLabel.setFont(new Font("Cooper Black", Font.ROMAN_BASELINE,20));

        // Adding Action Listeners to the Buttons:
        resBackToMainMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resFrame.setVisible(false); // disappear
                //resTable.setModel(new DefaultTableModel()); // clear the table for the next time
                DefaultTableModel tableModel = (DefaultTableModel) resTable.getModel();
                tableModel.setRowCount(0); // clear the table by setting the row count to 0
                view.showHelloScreen(); // show the first screen
            }
        });

        // Panels settings:
        // (set layouts)

        resTablePanel.setLayout(new BorderLayout());
        resUpperPanel.setLayout(new BoxLayout(resUpperPanel,BoxLayout.LINE_AXIS));
        resButtonsPanel.setLayout(new FlowLayout());

        // Add to the Panels

        resTablePanel.add(resTableScroller); // Add the scroller

        resUpperPanel.add(Box.createRigidArea(new Dimension(15,0))); // A spacer
        resUpperPanel.add(resLabel); // Add the label
        resUpperPanel.add(Box.createHorizontalGlue()); // GLue the components in this panel to the sides

        resButtonsPanel.add(resBackToMainMenuButton); // Add the button

        // Frame settings:

        resFrame.setPreferredSize(new Dimension(500, 300)); // set the size of the frame
        resFrame.setLayout(new BorderLayout()); // set the layout of the frame

        // Add to the Frame
        resFrame.add(resTablePanel, BorderLayout.CENTER);
        resFrame.add(resUpperPanel, BorderLayout.NORTH);
        resFrame.add(resButtonsPanel, BorderLayout.SOUTH);
        resFrame.add(new JLabel("    "), BorderLayout.EAST); // Spacer
        resFrame.add(new JLabel("    "), BorderLayout.WEST); // Spacer

        // Add closing settings:
        resFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

    }

    /**
     * Start showing this screen
     */
    public void go() {
        resFrame.pack();
        resFrame.setVisible(true); // show the frame
        logger.info("'result screen' is visible"); // log info
    }

    /**
     * This method shows a ShoppingList in the table of this class
     * @param list the ShoppingList object to show
     */
    public void showData(ShoppingList list){
        logger.info("showing data in the table");

        if (list != null && !list.equals(new ShoppingList())) { // if we have a list to show

            DefaultTableModel model = (DefaultTableModel) resTable.getModel(); // get the table model

            // for each ListProduct in the list
            for (ListProduct listProduct : list) {
                String name = listProduct.getProduct().getProductName(); // get the name
                int quantity = listProduct.getProductQuantity(); // get the quantity

                model.addRow(new Object[]{name,quantity}); // add the new data to the table
            }

        }else { // null or empty list

            logger.info("empty list - showing nothing in the table");

            // show massage - "you have nothing to buy : )"
            JOptionPane.showMessageDialog(null,"Nothing To Buy : )",
                                          "Information massage",JOptionPane.INFORMATION_MESSAGE);

            resFrame.setVisible(false); // disappear
            view.showHelloScreen(); // back to main menu
        }
    }

}
