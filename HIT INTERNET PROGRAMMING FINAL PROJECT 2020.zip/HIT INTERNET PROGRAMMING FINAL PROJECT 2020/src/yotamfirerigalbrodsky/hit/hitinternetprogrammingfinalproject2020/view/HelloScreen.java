package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents the first screen that a user will see when the GUI starts
 * It has one greetings label and two buttons
 */
public class HelloScreen {

    /**
     * view is the View (IView interface) object that created this instance of the class
     * helloFrame is the Frame of this screen
     * helloLabelPanel is a JPanel that contains the greetings label
     * helloButtonsPanel is a JPanel that contains the two buttons
     * helloLabel is the greetings label
     * helloEditButton a button that shows the Edit Screen when a user clicks it
     * helloCalculateButton a button that shows the Calculate Screen when a user clicks it
     * logger is the logger of this class
     */
    private IView view; // The view that created this instance of the class

    private JFrame helloFrame; // The Frame of this screen

    private JPanel helloLabelPanel; // contains JLabel
    private JPanel helloButtonsPanel; // contains the buttons

    private JLabel helloLabel; // The greetings label

    private JButton helloEditButton; // continue to the Edit Screen
    private JButton helloCalculateButton; // continue to the Calculate Screen

    private Logger logger = LogManager.getLogger(HelloScreen.class); // init the logger

    /**
     * The constructor of this class
     * @param view the view that created this instance of the class
     */
    public HelloScreen(IView view) {

        logger.info("creating the 'hello screen' to show"); // log info

        // initializing every object

        this.view = view; // set the view
        helloFrame = new JFrame("Shopping List Calculator"); // create the JFrame with a title
        // create the Panels
        helloLabelPanel = new JPanel();
        helloButtonsPanel = new JPanel();
        helloLabel = new JLabel("HELLO !", SwingConstants.CENTER); // create the label with a text
        // create the two buttons
        helloCalculateButton = new JButton("Calculate");
        helloEditButton = new JButton("Edit");

        // Basic components settings

        helloLabel.setFont(new Font("Cooper Black", Font.ROMAN_BASELINE,30));
        helloLabel.setPreferredSize(new Dimension(30, 200));
        //"Aharoni"
        helloEditButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));
        helloCalculateButton.setFont(new Font("Cooper Black", Font.PLAIN, 30));

        helloEditButton.setPreferredSize(new Dimension(200,50));
        helloCalculateButton.setPreferredSize(new Dimension(200,50));

        helloEditButton.setBackground(Color.YELLOW);
        helloCalculateButton.setBackground(Color.YELLOW);

        // Adding Action Listeners to the Buttons:

        helloEditButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                helloFrame.setVisible(false); // disappear
                view.showEditScreen(); // show edit screen
            }
        });

        helloCalculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.manageHelloScreenTransition();
            }
        });

        // Panel settings:

        helloLabelPanel.setLayout(new BorderLayout());
        helloButtonsPanel.setLayout(new FlowLayout());


        // Add to the Panels

        helloLabelPanel.add(helloLabel, BorderLayout.NORTH);

        helloButtonsPanel.add(helloEditButton);
        helloButtonsPanel.add(helloCalculateButton);

        // Frame settings:

        helloFrame.setPreferredSize(new Dimension(500, 300));
        helloFrame.setLayout(new BorderLayout());

        helloFrame.add(helloLabelPanel, BorderLayout.NORTH);
        helloFrame.add(helloButtonsPanel, BorderLayout.SOUTH);

        // Add closing settings:
        helloFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

    }

    /**
     * Start showing this screen
     */
    public void go() {
        helloFrame.pack(); // pack the frame
        helloFrame.setVisible(true); // show the frame
        logger.info("'hello screen' is visible"); // log info
    }

    /**
     * This method will make the frame to disappear (not visible)
     */
    public void disappear(){
        helloFrame.setVisible(false); // disappear
    }

}
