package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;

/**
 * This interface represents a view suitable for this final project
 * a class that implements this interface can be used as the view object in this final project
 */
public interface IView {

    /**
     * start showing the GUI
     */
    public void start();

    /**
     * close the GUI
     */
    public void close();

    /**
     * Shows the Hello Screen
     */
    public void showHelloScreen();

    /**
     * Shows the Edit Screen
     */
    public void showEditScreen();

    /**
     * Shows the Calculate Screen
     */
    public void showCalculateScreen();

    /**
     * Shows the Result Screen
     * @param list the shopping list to show in the result screen
     */
    public void showResultScreen(ShoppingList list);

    /**
     * send data to be kept in the database
     * @param shoppingList the list to be transferred to the database
     */
    public void sendData(ShoppingList shoppingList);

    /**
     * set the Table in the Result Screen
     * @param list the ShoppingList to show
     */
    public void setResultScreenTable(ShoppingList list);

    /**
     * This method shows the result screen
     */
    public void showResultScreen();

    /**
     * This method inserts items to the table inside the result screen
     * @param inStock the ShoppingList the user has in his stock
     */
    public void showItemsInResultScreenTable(ShoppingList inStock);

    /**
     * This method manages the transition between the "hello"
     * to the screens coming after in the GUI flow
     */
    public void manageHelloScreenTransition();

    /**
     * Make the "Hello" screen disappear
     */
    public void closeHelloScreen();
}
