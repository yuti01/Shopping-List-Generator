package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.view;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model.ShoppingList;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.IViewModel;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents a View for this final project
 */
public class View implements IView {

    /**
     * vm is the IViewModel object that is associated with this View instance
     * References to the 4 screens of the GUI
     * isListDefined is a boolean variable that is false when no shopping list is defined and true otherwise
     * logger is the logger of this class
     */
    private IViewModel vm; // the ViewModel object associated with this instance

    private HelloScreen helloScreen; // the first screen

    // other screens:
    private EditScreen editScreen;
    private CalculateScreen calculateScreen;
    private ResultScreen resultScreen;

   // private boolean isListDefined = false; // init the isListDefined variable as false

    private Logger logger = LogManager.getLogger(View.class); // init the logger

    ///////////////////////

    /**
     * The constructor of the View class
     */
    public View(IViewModel vm) {

        logger.info("setting the ViewModel object"); // log info

        // set the ViewModel object:
        this.vm = vm;

        logger.info("creating the screens"); // log info

        // create the screens
        helloScreen = new HelloScreen(this);
        editScreen = new EditScreen(this);
        calculateScreen = new CalculateScreen(this);
        resultScreen = new ResultScreen(this);

    }

    /**
     * start showing the GUI
     */
    @Override
    public void start() {
        logger.info("showing the hello screen (first screen) "); // log info
        showHelloScreen(); // show the first screen to the user
    }

    /**
     * close the GUI
     */
    @Override
    public void close() {
        // . . . no implementation needed (keeping this method for future versions)
    }

    /**
     * send data to be kept in the database
     * @param shoppingList the list to be transferred to the database
     */
    @Override
    public void sendData(ShoppingList shoppingList) {

        logger.info("sending the data to be kept in the data base"); // log info
        vm.keepDataInDB(shoppingList); // send the data to the data base
        logger.info("sending completed"); // log info

    }

    /**
     * Shows the Hello Screen
     */
    @Override
    public void showHelloScreen() {
        logger.info("showing 'hello screen'"); // log info

        helloScreen.go(); // start the hello screen
    }

    /**
     * Shows the Edit Screen
     */
    @Override
    public void showEditScreen() {
        logger.info("showing 'edit screen'"); // log info

        editScreen.go(); // start the Edit screen
    }

    /**
     * Shows the Calculate Screen
     */
    @Override
    public void showCalculateScreen() {
        logger.info("showing 'calculate screen'"); // log info

        calculateScreen.go(); // start the Calculate screen
    }

    /**
     * Shows the Result Screen
     */
    @Override
    public void showResultScreen(ShoppingList list) {
        logger.info("showing 'result screen'"); // log info
        resultScreen.go(); // start the result screen
        resultScreen.showData(list); // show the data
    }

    /**
     * Shows the Result Screen
     */
    @Override
    public void showResultScreen() {
        logger.info("showing 'result screen'"); // log info
        resultScreen.go(); // start the result screen
        //resultScreen.showData(list); // show the data
    }

    /**
     * This method sets the table of the ResultScreen
     * @param list the ShoppingList to show
     */
    @Override
    public void setResultScreenTable(ShoppingList list){
        resultScreen.showData(list); //show the list
    }

    /**
     * Get the value of isListDefined
     * @return the value of isListDefined
     */
    /*public boolean isListDefined() {
        if (!vm.isDataBaseEmpty()) isListDefined = true; // data base is not empty than the list is defined
        else isListDefined = false; // data base is empty than the list is not defined
        return isListDefined; // return the value of
    }*/

    /**
     * Set the value of isListDefined
     * @param listDefined the new value of isListDefined
     */
    /*public void setListDefined(boolean listDefined) {
        logger.info("setting 'isListDefined'"); // log info
        isListDefined = listDefined; // set the value
    }*/

    /**
     * This method shows the items in the result screen table
     */
    @Override
    public void showItemsInResultScreenTable(ShoppingList inStock){
        vm.showTheShouldBuyList(inStock); // call the ViewModel method
    }

    /**
     * this method is used to manage the transition between the "HelloScreen" and the screens coming
     * after it i  the flow
     */
    @Override
    public void manageHelloScreenTransition(){
       vm.manageHelloScreenTransition(); // call the ViewModel method
    }

    /**
     * This method will make the "HelloScreen" to disappear (not visible)
     */
    public void closeHelloScreen(){
        helloScreen.disappear(); // disappear from the screen
    }
}
