package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.exceptions.HITFinalProjectException;
import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.viewmodel.ViewModel;

import java.sql.*;
import java.util.Arrays;

/**
 * This class represents a Model for this final project
 */
public class Model implements IModel {

    /**
     * The "driver" String keeps the derbyDB driver that we will use
     * The "protocol" String keeps the protocol that is used when a connection is started
     * logger is the logger of this class
     * viewModel is the ViewModel object that is associated with this specific Model object
     */
    public static String driver = "org.apache.derby.jdbc.EmbeddedDriver"; // driver implementation
    public static String protocol = "jdbc:derby:finalProjectDB;create=true"; // connection protocol (database name: "finalProjectDB")
    private Logger logger = LogManager.getLogger(Model.class); // init the logger

    /**
     * The constructor of this class
     */
    public Model() { }

    /**
     * sets the ShoppingList in the data base
     * @param shoppingList the ShoppingList to be set
     * @throws HITFinalProjectException if a SQL error accrued
     */
    @Override
    public void setShoppingList(ShoppingList shoppingList) throws HITFinalProjectException{
        logger.info("setting the ShoppingList in the data base");

        clearDB(); // clear the data base

        Connection connection = null; // declare Connection object
        Statement statement = null; // declare Statement object

        try {
            connection = DriverManager.getConnection(protocol); // get connection

            for (ListProduct listProduct : shoppingList) { // for each item in the ShoppingList

                String nameProduct = listProduct.getProduct().getProductName();// take its name
                int productQuantity = listProduct.getProductQuantity();// take the quantity

                statement = connection.createStatement(); // create statement

                // insert the new data: name , quantity:
                statement.executeUpdate("INSERT INTO PRODUCTS (name, quantity)" +
                        " VALUES('" + nameProduct + "'," + productQuantity + ")");
            }
        } catch (SQLException e) {
            logger.error("SQL ERROR (from setShoppingList)"); //
            e.printStackTrace();
            throw new HITFinalProjectException("SQL ERROR. Could not set the new values");
        } finally {
            // close resources
            if (connection != null) {
                try {
                    connection.close(); // closing the connection
                } catch (Exception e) {
                    logger.error("could not close the connection"); // log error
                }
            }

            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    logger.error("could not close the statement"); // log error
                }
            }
        }

    }

    /**
     * returns the ShoppingList from the data base
     *
     * @return a ShoppingList object represents the shopping list that is kept in the data base
     * null if the data base is empty or missing
     */
    @Override
    public ShoppingList getShoppingList() throws HITFinalProjectException{
        logger.info("getting the ShoppingList from the data base"); // log info

        Connection connection = null; // declare Connection object
        Statement statement = null; // declare Statement object
        ResultSet resultSet = null; // declare ResultSet object
        ShoppingList shoppingList = new ShoppingList(); // init an empty ShoppingList

        try {
            connection = DriverManager.getConnection(protocol); // get connection
            statement = connection.createStatement(); // create statement

            if (isEmpty()) // checking if the database is empty, if so, return null
                return null;

            // Getting all the data from DataBase into resultSet
            resultSet = statement.executeQuery("SELECT name, quantity FROM PRODUCTS");

            while (resultSet.next()) { // running on resultSet

                String nameProduct = resultSet.getString("name"); // getting the name in the current row
                int productQuantity = resultSet.getInt("quantity"); // getting the quantity in the current row
                Product product = new Product(nameProduct); // creating object Product with the productName: nameProduct

                // creating ListProduct object
                ListProduct listProduct = new ListProduct(product, productQuantity);
                shoppingList.add(listProduct); // adding the object above (ListProduct) to the ShoppingList

            }

        } catch (SQLException e) {
            logger.error("SQL ERROR (from getShoppingList)"); // log error
            e.printStackTrace();
            throw new HITFinalProjectException("SQL ERROR. Could not get the Shopping List"); // throw exception
        } finally {
            // close resources
            if (connection != null) {
                try {
                    connection.close(); // closing the connection
                } catch (Exception e) {
                    logger.error("could not close the connection"); // log error
                }
            }

            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    logger.error("could not close the statement"); // log error
                }
            }

            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    logger.error("could not close the resultset"); // log error
                }
            }
        }

        return shoppingList;
    }

    /**
     * creates the data base
     */
    @Override
    public void initialize() throws HITFinalProjectException{
        logger.info("initializing the data base (if not exists)"); // log info
        Connection connection = null; // declare Connection object
        Statement statement = null; // declare Statement object
        try {
            Class.forName(driver); // add the driver to the drivers list (in the DriverManager)
            connection = DriverManager.getConnection(protocol); // get the connection to the data base
            statement = connection.createStatement(); // create statement

            // execute table creation
            statement.execute("CREATE TABLE PRODUCTS (name VARCHAR(80) NOT NULL , quantity INT, PRIMARY KEY (name))");

        } catch (SQLException e) {
            logger.error("SQL ERROR (from initialize)"); // log error
            e.printStackTrace();
            throw new HITFinalProjectException("SQL ERROR. Could not create the table 'PRODUCTS'\nIf this table already exists please ignore this exception"); // throw exception
        } catch (ClassNotFoundException e) {
            logger.error("CLASS NOT FOUND ERROR"); // log error
            e.printStackTrace();
            throw new HITFinalProjectException("CLASS NOT FOUND ERROR. Could not add the driver to the drivers list"); // throw exception
        } finally {
            // close resources
            if (connection != null) {
                try {
                    connection.close(); // closing the connection
                } catch (Exception e) {
                    logger.error("could not close the connection"); // log error
                }
            }

            if (statement != null) {
                try {
                    statement.close(); // closing the statement
                } catch (Exception e) {
                    logger.error("could not close the statement"); // log error
                }
            }
        }
    }

    /**
     * closes the data base
     */
    @Override
    public void dropDB() throws HITFinalProjectException{
        logger.info("dropping the data base"); // log info
        Connection connection = null; // declare Connection object
        Statement statement = null; // declare Statement object
        try {
            connection = DriverManager.getConnection(protocol); // get connection
            statement = connection.createStatement(); // create statement
            statement.execute("DROP TABLE PRODUCTS"); // Drop table
        } catch (SQLException e) {
            logger.error("SQL ERROR (from dropDB)");
            e.printStackTrace();
            throw new HITFinalProjectException("SQL ERROR. Could not drop the database"); // throw exception
        } finally {
            // close resources
            if (connection != null) {
                try {
                    connection.close(); // closing the connection
                } catch (Exception e) {
                    logger.error("could not close the connection"); // log error
                }
            }

            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    logger.error("could not close the statement"); // log error
                }
            }
        }
    }

    /**
     * checks if the data base is empty
     *
     * @return true if the data base is empty or not initialized
     * false if the data base has some data
     */
    @Override
    public boolean isEmpty() throws HITFinalProjectException{
        Connection connection = null; // declare Connection object
        Statement statement = null; // declare Statement object
        ResultSet resultSet = null; // declare ResultSet object

        try {
            connection = DriverManager.getConnection(protocol); // get connection
            statement = connection.createStatement(); // create statement

            // Check the amount of items in the DataBase
            resultSet = statement.executeQuery("SELECT count(*) FROM PRODUCTS");
            resultSet.next();

            if (resultSet.getInt(1) == 0)// the dataBase is empty
                return true;

        } catch (SQLException e) {
            logger.error("SQL ERROR (from isEmpty)"); //log details
            e.printStackTrace();
            throw new HITFinalProjectException("SQL ERROR. Could not check if the data base is empty"); // throw exception
        } finally {
            // close resources
            if (connection != null) { // if there is a connection to close
                try {
                    connection.close(); // closing the connection
                } catch (Exception e) {
                    logger.error("could not close the connection"); // log error
                }
            }

            if (statement != null) {
                try {
                    statement.close();
                } catch (Exception e) {
                    logger.error("could not close the statement"); // log error
                }
            }

            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    logger.error("could not close the resultset"); // log error
                }
            }
        }

        return false; // the data base is not empty
    }

    /**
     * clear the data base with this method
     */
    @Override
    public void clearDB() throws HITFinalProjectException{
        if (!isEmpty()) { // data base is not empty

            dropDB(); // drop the table 'PRODUCTS'

            // create it once again
            Connection connection = null; // declare Connection object
            Statement statement = null; // declare Statement object

            try {
                connection = DriverManager.getConnection(protocol); // get connection

                statement = connection.createStatement(); // create statement
                // execute table creation
                statement.execute("CREATE TABLE PRODUCTS (name VARCHAR(80) NOT NULL , quantity INT, PRIMARY KEY (name))");
            } catch (SQLException e) {
                logger.error("SQL ERROR (from clearDB)"); // log error
                e.printStackTrace();
                throw new HITFinalProjectException("SQL ERROR. Could not clear the database"); // throw an exception
            }
        }
    }

}
