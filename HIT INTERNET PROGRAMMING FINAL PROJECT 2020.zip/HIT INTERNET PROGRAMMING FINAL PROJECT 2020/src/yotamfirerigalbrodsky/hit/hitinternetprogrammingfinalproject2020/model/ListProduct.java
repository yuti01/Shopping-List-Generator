package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;

/**
 *  This class represents a single line in the shopping list:
 *  the Product object (a String) represent the Product in this line of the list
 *  the quantity of the product (an int)
 */
public class ListProduct {

    /**
     * product is the product object
     * quantity of the product
     * logger is the logger of this class
     */
    private Product product; // The product object
    private int productQuantity; // the quantity of the product
    private Logger logger = LogManager.getLogger(ListProduct.class); // init the logger

    /**
     * The ListProduct constructor
     * @param product a Product object that holds the Product object for this line of the list
     * @param productQuantity an integer that holds the the quantity of the product
     */
    public ListProduct(Product product, int productQuantity) {
        logger.info("creating a new list product"); // log info
        this.setProduct(product); // set the product
        this.setProductQuantity(productQuantity); // set the quantity
    }

    /**
     * Getter for the product attribute
     * @return the Product object of this line
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Setter for the Product object in this specific line
     * @param product a Product object that holds the new Product object for this line of the list
     */
    public void setProduct(Product product) {
        logger.info("setting the Product of a ListProduct object"); // log info
        this.product = product; // setting the product
    }

    /**
     * Getter for the productQuantity variable
     * @return the quantity of the product
     */
    public int getProductQuantity() {
        return productQuantity;
    }

    /**
     * Setter of the product's quantity
     * @param productQuantity an integer that holds the new quantity of the product
     */
    public void setProductQuantity(int productQuantity) {
        logger.info("setting the quantity of a ListProduct object"); // log info
        this.productQuantity = productQuantity; // setting the quantity
    }

    /**
     * Check if the two ListProducts have the same value
     * @param obj the other ListProduct object
     * @return true if they are equal
     *         false if they are not
     */
    @Override
    public boolean equals(Object obj) {
        // checks if obj is null
        if (obj == null)
            return false;

        // checks if obj is a Product
        if (!ShoppingList.class.isAssignableFrom(obj.getClass()))
            return false;

        ListProduct otherListProduct = (ListProduct) obj; // get the other ShoppingList

        if (!product.equals(otherListProduct.getProduct())) // if the Products are not equal return false
            return false;

        // if the quantities are not equal return false
        if (getProductQuantity() != otherListProduct.getProductQuantity())
            return false;

        // otherwise return true
        return true;
    }
}
