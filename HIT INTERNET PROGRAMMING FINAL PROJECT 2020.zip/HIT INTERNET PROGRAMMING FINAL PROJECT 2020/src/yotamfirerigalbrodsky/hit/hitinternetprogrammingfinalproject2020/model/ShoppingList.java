package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class represents a shopping list (multiple ListProduct objects)
 * The ListProduct objects are kept inside an ArrayList called listOfProducts
 * You can Iterate over this class in a "for-each" loop
 */
public class ShoppingList implements Iterable<ListProduct>{


    /**
     * This List represents the list of products in this ShoppingList object
     * logger is the logger of this class
     */
    private List<ListProduct> listOfProducts; // The list of the products that are in the shopping list
    private static Logger logger = LogManager.getLogger(ShoppingList.class); // init the logger

    /**
     * Default constructor
     * Sets the listOfProducts to an empty ArrayList
     */
    public ShoppingList() {
        logger.info("creating a new ShoppingList (Default constructor)");
        this.listOfProducts = new ArrayList<ListProduct>(); // using the ArrayList class as the List
    }

    /**
     * The ShoppingList constructor
     * @param listOfProducts the ArrayList to be the list of products in the ShoppingList object
     */
    public ShoppingList(ArrayList<ListProduct> listOfProducts) {
        logger.info("creating a new ShoppingList with a list of products");
        this.setListOfProducts(listOfProducts);
    }

    /**
     * A Getter for the listOfProducts object
     * @return the listOfProducts List object
     */
    public List<ListProduct> getListOfProducts() {
        return listOfProducts;
    }

    /**
     * A Setter for the listOfProducts object
     * @param listOfProducts the new ArrayList to be the listOfProducts object inside the ShoppingList object
     */
    public void setListOfProducts(ArrayList<ListProduct> listOfProducts) {
        logger.info("setting the list of product of a ShoppingList object");
        this.listOfProducts = listOfProducts;
    }

    /**
     * Adds a new item (of type ListProduct) to the listOfProducts ArrayList inside the ShoppingList object
     * @param listProduct the ListProduct to be added
     */
    public void add(ListProduct listProduct){
        logger.info("adding a new item to the ShoppingList");
        getListOfProducts().add(listProduct);
    }

    /**
     * Adds a new item (of type ListProduct) to the listOfProducts ArrayList inside the ShoppingList object
     * in a specific index
     * @param index an integer represents the index in which the new item will be added
     * @param listProduct the ListProduct to be added
     */
    public void add(int index, ListProduct listProduct){
        logger.info("adding a new item to the ShoppingList in index: " + index); // log info
        getListOfProducts().add(index,listProduct);
    }

    /**
     * Adds a ShoppingList to the end of the ShoppingList called the method
     * @param otherShoppingList the ShoppingList to be added
     */
    public void addAll(ShoppingList otherShoppingList){
        logger.info("adding many items to the ShoppingList"); // log info
        this.getListOfProducts().addAll(otherShoppingList.getListOfProducts());
    }

    /**
     * removes the specific ListProduct object
     * @param listProduct the ListProduct object to be removed
     */
    public void remove(ListProduct listProduct){
        logger.info("removing an item from the ShoppingList");
        getListOfProducts().remove(listProduct);
    }

    /**
     * removes the ListProduct object in certain index
     * @param index an integer represents the index of the item to be removed
     */
    public void remove(int index){
        logger.info("removing an item in index" + index + "from the ShoppingList"); // log info
        getListOfProducts().remove(index); // remove the item
    }

    /**
     * remove all items from the ShoppingList object
     */
    public void clear(){
        logger.info("clearing a ShoppingList"); // log info
        getListOfProducts().clear(); // clear the ShoppingList object
    }

    /**
     * creates and returns a shallow copy of the original ShoppingList object
     * resembles clone method but without issues
     * @return a shallow copy of the original ShoppingList object
     */
    public ShoppingList getCopy(){
        // Declaring an ArrayList with a copy constructor
        ArrayList<ListProduct> copyList = new ArrayList<>(this.getListOfProducts());

        // return a new ShoppingList object with the copyList as its listOfProducts attribute
        return new ShoppingList(copyList);
    }

    /**
     * checks if a specific ListProduct object is inside the ShoppingList object (same Product and quantity)
     * @param listProduct the ListProduct object to search for
     * @return true if the ListProduct object is inside the ShoppingList object
     *         false if not
     */
    public boolean contains(ListProduct listProduct){
        // search in the listOfProducts for the specific product object with the same quantity
        for (ListProduct aListProduct : this.getIterableObject()) {
            if (aListProduct.getProduct().equals(listProduct.getProduct())
                    && listProduct.getProductQuantity() == aListProduct.getProductQuantity()) // Found it
                return true;
        }

        // no such Product in the ShoppingList
        return false;
    }

    /**
     * check if a ShoppingList contains a Product
     * @param product the Product object to search for
     * @return true if the product is contained by this specific ShoppingList
     *         false otherwise
     */
    public boolean contains(Product product){
        // search in the listOfProducts for the specific product object
        for (ListProduct listProduct : this.getIterableObject()) {
            if (listProduct.getProduct().equals(product)) // Found it
                return true;
        }

        // no such Product in the ShoppingList
        return false;
    }

    /**
     * checks if the ShoppingList object is empty
     * @return true if the ShoppingList object is empty
     *         false if not
     */
    public boolean isEmpty() {
        return getListOfProducts().isEmpty();
    }

    /**
     * get the ListProduct in a specific index
     * @param index an integer represents the index of the object to be returned
     * @return the ListProduct object in the specified index
     */
    public ListProduct get(int index){
        return getListOfProducts().get(index);
    }

    /**
     * get the ListProduct object with a specific
     * @param product
     * @return
     */
    public ListProduct get(Product product){

        // for each ListProduct in the ShoppingList object, check if the product is the same as needed
        // yes - return the current ListProduct object
        // else - continue
        for (ListProduct listProduct : this){
            Product currentProduct = listProduct.getProduct();
            if (currentProduct.equals(product)){
                return listProduct;
            }

        }

        return null; // no such Product in the list
    }

    /**
     * get the index of a specific ListProduct object
     * @param listProduct the ListProduct object to search for its index
     * @return an integer represents the index of listProduct
     */
    public int indexOf(ListProduct listProduct){
        return getListOfProducts().indexOf(listProduct);
    }

    /**
     * returns an iterable object to iterate over the ShoppingList in a "for-each" loop
     * @return an List to iterate over
     * @deprecated use simple "for-each" loop instead
     */
    @Deprecated
    public List<ListProduct> getIterableObject(){
        return getListOfProducts();
    }

    /**
     * returns a new ShoppingList represents the items a costumer should get to have
     * all the items in the shouldHaveProducts with the right quantity
     * @param shouldHaveProducts a ShoppingList object represents the items a costumer should have
     * @param inStockProducts a ShoppingList object represents the items a costumer have in its stock
     * @return null if the shouldHaveProducts parameter is null
     *
     */
    public static ShoppingList remainsToBuy(ShoppingList shouldHaveProducts, ShoppingList inStockProducts){
        logger.info("calculating which items the user should buy - ShoppingList subtraction "); // log info
        // validation checks and edge cases
        if(shouldHaveProducts == null)  // first list is null then the behavior is not defined - return null
            return null;

        /* second list is empty then return the first list
           second list is null then return the first list
           same return statement for both cases
         */
        if(inStockProducts == null || inStockProducts.isEmpty())
            return shouldHaveProducts;

        /* first and second lists are equal - return new empty list
           first list is empty then return an empty list
         */
        if(shouldHaveProducts.equals(inStockProducts) || shouldHaveProducts.isEmpty() )
            return new ShoppingList(); // return an empty ShoppingList

        // END OF EDGE CASES

        ShoppingList remainsToBuyList = new ShoppingList(); // initialize the ShoppingList to return

        /* check for each ListProduct in the "should have" list if it exists in the "stock" list
           (by the Product object not by the quantity)
            yes - add the new item with the quantity the customer should add to his stock
                  (unless he has in stock more than he should have)
            no - add the new item with the full quantity
         */
        for (ListProduct listProduct : shouldHaveProducts.getIterableObject()){
            if(inStockProducts.contains(listProduct.getProduct()))
            {
                /* keep the new quantity of the new ListProduct object
                   The new quantity is the result of the subtraction operation between
                   the "should have" quantity and the "in stock" quantity
                */
                int newQuantity = listProduct.getProductQuantity()
                                  - inStockProducts.get(listProduct.getProduct()).getProductQuantity();

                if (newQuantity > 0)
                 remainsToBuyList.add(new ListProduct(listProduct.getProduct(), newQuantity));
                // else - do not add this item
            }
            // the product does not exist "in stock" - add it to the list to return
            // with the same quantity as it "should be"
            else remainsToBuyList.add(new ListProduct(listProduct.getProduct(), listProduct.getProductQuantity()));

        }

        logger.info("returning the ShoppingList: " + remainsToBuyList.toString()); // log info

        // return the created ShoppingList
        return remainsToBuyList;
    }

    /**
     * returns the size of the list
     * @return an integer represents the size of the list
     */
    public int size(){
        return getListOfProducts().size();
    }

    /**
     * get a matrix of objects representing thisShoppingList object
     * @return a matrix of objects representing thisShoppingList object
     */
    public Object[][] toMatrix(){
        logger.info("creating a matrix representing the ShoppingList object"); // log info

        // initializing the Object Matrix
        Object[][] data = new Object[size()][2];

        // Looping through each ListProduct
        for (int i = 0; i<size();i++){
            data[i][0] = this.get(i).getProduct().getProductName(); // data[i][0] contains the Product's name (String)
            data[i][1] = this.get(i).getProductQuantity(); // data[i][1] contains the Product's Quantity (int)
        }

        return data; // returning the Matrix
    }

    /**
     * transforms a JTable object into a ShoppingList object
     * @param table the JTable to be transformed
     * @return a ShoppingList object carrying the data from the JTable
     */
    public static ShoppingList tableToShoppingList(JTable table){
        ShoppingList list = new ShoppingList(); // initialize empty ShoppingList
        if (table.getRowCount() == 0){ // no items in table
            logger.warn("table is empty"); // log warn
            return null;
        }
        for (int i = 0; i < table.getRowCount(); i++) { // For each of the table rows
            // Create the new Product to be added (in a ListProduct object)
            Product newProduct = new Product(table.getModel().getValueAt(i,0).toString());

            // Keep the new Product's quantity

            int newQuantity = (int) table.getModel().getValueAt(i,1);

            // Create the new ListProduct to be added
            ListProduct newListProduct = new ListProduct(newProduct, newQuantity);
            list.add(newListProduct); // Add the new item
        }
        logger.info("returning the ShoppingList: " + list.toString()); // log info
        return list; // return the created list
    }

    /**
     * Compares this specific ShoppingList object for equality
     * @param obj the other ShoppingList to be compared
     * @return true if and only if the specified object is also a ShoppingList,
     *         both lists have the same size, and all corresponding pairs of elements in the two lists are equal.
     *         false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        // checks if obj is null
        if (obj == null)
            return false;

        // checks if obj is a Product
        if (!ShoppingList.class.isAssignableFrom(obj.getClass()))
            return false;

        ShoppingList otherShoppingList = (ShoppingList) obj; // get the other ShoppingList

        // check if the lists are equal and return the answer

       if (this.getListOfProducts().size() != otherShoppingList.getListOfProducts().size())
           return false;

       for (ListProduct currentListProduct : this){
           if (this.getNumberOfOccurrencesInThisShoppingList(currentListProduct.getProduct())
           != otherShoppingList.getNumberOfOccurrencesInThisShoppingList(currentListProduct.getProduct()))
               return false;

           if (currentListProduct.getProductQuantity() !=
                   otherShoppingList.get(currentListProduct.getProduct()).getProductQuantity())
               return false;
       }

       return true;
    }

    /**
     * get the number of occurrences of a specific Product in this ShoppingList object
     * @param productToSearchFor the Product to search for
     * @return the number of occurrences of the given Product object in this ShoppingList
     */
    private int getNumberOfOccurrencesInThisShoppingList(Product productToSearchFor){
        int counter = 0; // set counter to 0

        for (ListProduct currentListProduct : this){
           if (currentListProduct.getProduct().equals(productToSearchFor)) // if its the product we need
               counter++; // increment the counter
        }

        return counter; // return the counter
    }

    /**
     * return a String object describing this specific ShoppingList object
     * @return a String object describing this specific ShoppingList object
     */
    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer(); // get a StringBuffer

        for (ListProduct listProduct : this){
            buffer.append("name:" + listProduct.getProduct().getProductName() + // append the details
                    " quantity:" + listProduct.getProductQuantity() + "\n");
        }

        return buffer.toString(); // return the String from the StringBuffer
    }

    /**
     * Returns an iterator over elements of type {@code ListProduct}.
     *
     * @return an Iterator.
     */
    @Override
    public Iterator<ListProduct> iterator() {
        return listOfProducts.iterator();
    }
}
