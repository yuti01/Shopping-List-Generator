package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model;

import yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.exceptions.HITFinalProjectException;

/**
 * This interface represents a model suitable for this final project
 * a class that implements this interface can be used as the model object in this final project
 */
public interface IModel {

    /**
     * sets the ShoppingList in the data base
     * @param shoppingList the ShoppingList to be set
     * @throws HITFinalProjectException if a SQL error accrued
     */
    public void setShoppingList(ShoppingList shoppingList) throws HITFinalProjectException;

    /**
     * returns the ShoppingList from the data base
     * @return a ShoppingList object represents the shopping list that is kept in the data base
     *         null if the data base is empty or missing
     */
    public ShoppingList getShoppingList() throws HITFinalProjectException;

    /**
     * creates the data base
     */
    public void initialize() throws HITFinalProjectException;

    /**
     * drops the data base
     */
    public void dropDB() throws HITFinalProjectException;

    /**
     * checks if the data base is empty
     * @return true if the data base is empty or not initialized
     *         false if the data base has some data
     */
    public boolean isEmpty() throws HITFinalProjectException;

    /**
     * clear the data base with this method
     */
    public void clearDB() throws HITFinalProjectException;
}
