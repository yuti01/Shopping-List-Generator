package yotamfirerigalbrodsky.hit.hitinternetprogrammingfinalproject2020.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class represents a Product
 * in this version the Product object has only one attribute called productName
 * productName is a String object represents the name of the Product
 */
public class Product {

    /**
     * this String represents the product's name
     * logger is the logger of this class
     */
    private String productName; // The product's name
    private Logger logger = LogManager.getLogger(Product.class); // init the logger

    /**
     * The constructor of the Product class
     * @param productName the product's name
     */
    public Product(String productName) {
        logger.info("creating new product with name '" + productName + "'");
       setProductName(productName);
    }

    /**
     * A Getter for the product's name
     * @return a String object represents the product's name
     */
    public String getProductName() {
        return productName;
    }

    /**
     * A Setter for the product's name
     * @param productName a String represents the new product's name to be set
     */
    public void setProductName(String productName) {
        logger.info("setting the name of a product - old name:'"+ getProductName() +"' new name: '" + productName + "'");
        this.productName = productName;
    }

    /**
     * checks if two Product objects are equal
     * @param obj the other object to be compared
     * @return true if the objects are equal
     *         false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        // checks if obj is null
        if (obj == null)
            return false;

        // checks if obj is a Product
        if (!Product.class.isAssignableFrom(obj.getClass()))
            return false;

        final Product otherProduct = (Product) obj;

        // check if the two Products have the same name - return the answer
        return this.getProductName().equals(otherProduct.getProductName());
    }

    /**
     * returns a String object describing the Product object
     * @return a String object describing the Product object (the Product's name)
     */
    @Override
    public String toString() {
        return this.getProductName();
    }
}
